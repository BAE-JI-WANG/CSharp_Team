﻿
namespace Book_re
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.bt_mypage = new Sunny.UI.UIButton();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.uiTabControl1 = new Sunny.UI.UITabControl();
            this.tb1 = new System.Windows.Forms.TabPage();
            this.uiPanel1 = new Sunny.UI.UIPanel();
            this.uiLabel11 = new Sunny.UI.UILabel();
            this.tb2 = new System.Windows.Forms.TabPage();
            this.uiPanel2 = new Sunny.UI.UIPanel();
            this.DGV_rank2 = new Sunny.UI.UIDataGridView();
            this.dataGridViewTextBoxColumn64 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn70 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uiLabel10 = new Sunny.UI.UILabel();
            this.tb3 = new System.Windows.Forms.TabPage();
            this.uiPanel3 = new Sunny.UI.UIPanel();
            this.DGV_rank3 = new Sunny.UI.UIDataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uiLabel9 = new Sunny.UI.UILabel();
            this.tb4 = new System.Windows.Forms.TabPage();
            this.uiPanel4 = new Sunny.UI.UIPanel();
            this.DGV_rank4 = new Sunny.UI.UIDataGridView();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uiLabel8 = new Sunny.UI.UILabel();
            this.tb5 = new System.Windows.Forms.TabPage();
            this.uiPanel5 = new Sunny.UI.UIPanel();
            this.DGV_rank5 = new Sunny.UI.UIDataGridView();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uiLabel7 = new Sunny.UI.UILabel();
            this.tb6 = new System.Windows.Forms.TabPage();
            this.uiPanel6 = new Sunny.UI.UIPanel();
            this.DGV_rank6 = new Sunny.UI.UIDataGridView();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uiLabel6 = new Sunny.UI.UILabel();
            this.tb7 = new System.Windows.Forms.TabPage();
            this.uiPanel7 = new Sunny.UI.UIPanel();
            this.DGV_rank7 = new Sunny.UI.UIDataGridView();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uiLabel5 = new Sunny.UI.UILabel();
            this.tb8 = new System.Windows.Forms.TabPage();
            this.uiPanel8 = new Sunny.UI.UIPanel();
            this.DGV_rank8 = new Sunny.UI.UIDataGridView();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uiLabel4 = new Sunny.UI.UILabel();
            this.tb9 = new System.Windows.Forms.TabPage();
            this.uiPanel9 = new Sunny.UI.UIPanel();
            this.DGV_rank9 = new Sunny.UI.UIDataGridView();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uiLabel3 = new Sunny.UI.UILabel();
            this.tb10 = new System.Windows.Forms.TabPage();
            this.uiPanel10 = new Sunny.UI.UIPanel();
            this.DGV_rank10 = new Sunny.UI.UIDataGridView();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn56 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uiLabel2 = new Sunny.UI.UILabel();
            this.DGV_Subject = new Sunny.UI.UIDataGridView();
            this.rankDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subjectDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bt_signup = new Sunny.UI.UIButton();
            this.bt_signin = new Sunny.UI.UIButton();
            this.bt_exit = new Sunny.UI.UIImageButton();
            this.bt_search = new Sunny.UI.UIButton();
            this.txt_search = new Sunny.UI.UITextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bt_signout = new System.Windows.Forms.Label();
            this.bt_icon_signout = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_chart = new Sunny.UI.UIImageButton();
            this.bt_recommend = new Sunny.UI.UIImageButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bookBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn65 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn66 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn67 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn68 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn69 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn52 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn53 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn54 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn55 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookRankBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pyear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.publisherDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.writerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.titleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookrank = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGV_rank1 = new Sunny.UI.UIDataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.uiTabControl1.SuspendLayout();
            this.tb1.SuspendLayout();
            this.uiPanel1.SuspendLayout();
            this.tb2.SuspendLayout();
            this.uiPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank2)).BeginInit();
            this.tb3.SuspendLayout();
            this.uiPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank3)).BeginInit();
            this.tb4.SuspendLayout();
            this.uiPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank4)).BeginInit();
            this.tb5.SuspendLayout();
            this.uiPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank5)).BeginInit();
            this.tb6.SuspendLayout();
            this.uiPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank6)).BeginInit();
            this.tb7.SuspendLayout();
            this.uiPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank7)).BeginInit();
            this.tb8.SuspendLayout();
            this.uiPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank8)).BeginInit();
            this.tb9.SuspendLayout();
            this.uiPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank9)).BeginInit();
            this.tb10.SuspendLayout();
            this.uiPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Subject)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bt_exit)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bt_icon_signout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bt_chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bt_recommend)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookRankBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.bt_mypage);
            this.panel1.Controls.Add(this.uiLabel1);
            this.panel1.Controls.Add(this.uiTabControl1);
            this.panel1.Controls.Add(this.DGV_Subject);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.bt_signup);
            this.panel1.Controls.Add(this.bt_signin);
            this.panel1.Controls.Add(this.bt_exit);
            this.panel1.Controls.Add(this.bt_search);
            this.panel1.Controls.Add(this.txt_search);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1226, 689);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(733, 23);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(33, 35);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // bt_mypage
            // 
            this.bt_mypage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_mypage.FillColor = System.Drawing.Color.Transparent;
            this.bt_mypage.FillDisableColor = System.Drawing.Color.Transparent;
            this.bt_mypage.FillHoverColor = System.Drawing.Color.Transparent;
            this.bt_mypage.FillPressColor = System.Drawing.Color.Transparent;
            this.bt_mypage.FillSelectedColor = System.Drawing.Color.Transparent;
            this.bt_mypage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.bt_mypage.ForeColor = System.Drawing.Color.Black;
            this.bt_mypage.Location = new System.Drawing.Point(748, 23);
            this.bt_mypage.MinimumSize = new System.Drawing.Size(1, 1);
            this.bt_mypage.Name = "bt_mypage";
            this.bt_mypage.RectColor = System.Drawing.Color.Transparent;
            this.bt_mypage.RectDisableColor = System.Drawing.Color.Transparent;
            this.bt_mypage.RectHoverColor = System.Drawing.Color.Transparent;
            this.bt_mypage.RectPressColor = System.Drawing.Color.Transparent;
            this.bt_mypage.RectSelectedColor = System.Drawing.Color.Transparent;
            this.bt_mypage.Size = new System.Drawing.Size(100, 35);
            this.bt_mypage.Style = Sunny.UI.UIStyle.Custom;
            this.bt_mypage.TabIndex = 14;
            this.bt_mypage.Text = "Mypage";
            this.bt_mypage.Click += new System.EventHandler(this.bt_mypage_Click);
            // 
            // uiLabel1
            // 
            this.uiLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.uiLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.uiLabel1.Location = new System.Drawing.Point(196, 220);
            this.uiLabel1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(276, 23);
            this.uiLabel1.TabIndex = 11;
            this.uiLabel1.Text = "  인기태그 TOP10";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiTabControl1
            // 
            this.uiTabControl1.Controls.Add(this.tb1);
            this.uiTabControl1.Controls.Add(this.tb2);
            this.uiTabControl1.Controls.Add(this.tb3);
            this.uiTabControl1.Controls.Add(this.tb4);
            this.uiTabControl1.Controls.Add(this.tb5);
            this.uiTabControl1.Controls.Add(this.tb6);
            this.uiTabControl1.Controls.Add(this.tb7);
            this.uiTabControl1.Controls.Add(this.tb8);
            this.uiTabControl1.Controls.Add(this.tb9);
            this.uiTabControl1.Controls.Add(this.tb10);
            this.uiTabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.uiTabControl1.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiTabControl1.ItemSize = new System.Drawing.Size(150, 40);
            this.uiTabControl1.Location = new System.Drawing.Point(522, 220);
            this.uiTabControl1.MainPage = "";
            this.uiTabControl1.MenuStyle = Sunny.UI.UIMenuStyle.Custom;
            this.uiTabControl1.Name = "uiTabControl1";
            this.uiTabControl1.SelectedIndex = 0;
            this.uiTabControl1.Size = new System.Drawing.Size(603, 434);
            this.uiTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.uiTabControl1.Style = Sunny.UI.UIStyle.Custom;
            this.uiTabControl1.TabBackColor = System.Drawing.Color.Maroon;
            this.uiTabControl1.TabIndex = 10;
            this.uiTabControl1.TabSelectedColor = System.Drawing.Color.Firebrick;
            this.uiTabControl1.TabSelectedForeColor = System.Drawing.Color.White;
            this.uiTabControl1.TabSelectedHighColor = System.Drawing.Color.Brown;
            // 
            // tb1
            // 
            this.tb1.Controls.Add(this.uiPanel1);
            this.tb1.Location = new System.Drawing.Point(0, 40);
            this.tb1.Name = "tb1";
            this.tb1.Size = new System.Drawing.Size(603, 394);
            this.tb1.TabIndex = 0;
            this.tb1.UseVisualStyleBackColor = true;
            // 
            // uiPanel1
            // 
            this.uiPanel1.Controls.Add(this.DGV_rank1);
            this.uiPanel1.Controls.Add(this.uiLabel11);
            this.uiPanel1.FillColor = System.Drawing.Color.Maroon;
            this.uiPanel1.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiPanel1.ForeColor = System.Drawing.Color.Maroon;
            this.uiPanel1.ForeDisableColor = System.Drawing.Color.Maroon;
            this.uiPanel1.Location = new System.Drawing.Point(4, 4);
            this.uiPanel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel1.Name = "uiPanel1";
            this.uiPanel1.Radius = 15;
            this.uiPanel1.RectColor = System.Drawing.Color.Maroon;
            this.uiPanel1.RectDisableColor = System.Drawing.Color.Maroon;
            this.uiPanel1.Size = new System.Drawing.Size(595, 385);
            this.uiPanel1.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel1.TabIndex = 0;
            this.uiPanel1.Text = null;
            this.uiPanel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel11
            // 
            this.uiLabel11.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiLabel11.Location = new System.Drawing.Point(198, 156);
            this.uiLabel11.Name = "uiLabel11";
            this.uiLabel11.Size = new System.Drawing.Size(198, 73);
            this.uiLabel11.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel11.TabIndex = 9;
            this.uiLabel11.Text = "1";
            this.uiLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb2
            // 
            this.tb2.Controls.Add(this.uiPanel2);
            this.tb2.Location = new System.Drawing.Point(0, 40);
            this.tb2.Name = "tb2";
            this.tb2.Size = new System.Drawing.Size(603, 394);
            this.tb2.TabIndex = 1;
            this.tb2.UseVisualStyleBackColor = true;
            // 
            // uiPanel2
            // 
            this.uiPanel2.Controls.Add(this.DGV_rank2);
            this.uiPanel2.Controls.Add(this.uiLabel10);
            this.uiPanel2.FillColor = System.Drawing.Color.Maroon;
            this.uiPanel2.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiPanel2.Location = new System.Drawing.Point(4, 4);
            this.uiPanel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel2.Name = "uiPanel2";
            this.uiPanel2.Radius = 15;
            this.uiPanel2.RectColor = System.Drawing.Color.Maroon;
            this.uiPanel2.Size = new System.Drawing.Size(595, 385);
            this.uiPanel2.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel2.TabIndex = 0;
            this.uiPanel2.Text = null;
            this.uiPanel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DGV_rank2
            // 
            this.DGV_rank2.AllowUserToAddRows = false;
            this.DGV_rank2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.DGV_rank2.AutoGenerateColumns = false;
            this.DGV_rank2.BackgroundColor = System.Drawing.Color.White;
            this.DGV_rank2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.DGV_rank2.ColumnHeadersHeight = 32;
            this.DGV_rank2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_rank2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn64,
            this.dataGridViewTextBoxColumn65,
            this.dataGridViewTextBoxColumn66,
            this.dataGridViewTextBoxColumn67,
            this.dataGridViewTextBoxColumn68,
            this.dataGridViewTextBoxColumn69,
            this.dataGridViewTextBoxColumn70});
            this.DGV_rank2.DataSource = this.bookBindingSource3;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_rank2.DefaultCellStyle = dataGridViewCellStyle8;
            this.DGV_rank2.EnableHeadersVisualStyles = false;
            this.DGV_rank2.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.DGV_rank2.GridColor = System.Drawing.Color.Maroon;
            this.DGV_rank2.Location = new System.Drawing.Point(4, 4);
            this.DGV_rank2.Name = "DGV_rank2";
            this.DGV_rank2.ReadOnly = true;
            this.DGV_rank2.RectColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank2.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.DGV_rank2.RowHeadersVisible = false;
            this.DGV_rank2.RowHeadersWidth = 82;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank2.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.DGV_rank2.RowTemplate.Height = 29;
            this.DGV_rank2.SelectedIndex = -1;
            this.DGV_rank2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_rank2.ShowGridLine = true;
            this.DGV_rank2.Size = new System.Drawing.Size(588, 378);
            this.DGV_rank2.StripeEvenColor = System.Drawing.Color.Snow;
            this.DGV_rank2.StripeOddColor = System.Drawing.Color.Snow;
            this.DGV_rank2.Style = Sunny.UI.UIStyle.Custom;
            this.DGV_rank2.StyleCustomMode = true;
            this.DGV_rank2.TabIndex = 12;
            this.DGV_rank2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_rank_CellClick);
            // 
            // dataGridViewTextBoxColumn64
            // 
            this.dataGridViewTextBoxColumn64.DataPropertyName = "bookrank";
            this.dataGridViewTextBoxColumn64.FillWeight = 50F;
            this.dataGridViewTextBoxColumn64.HeaderText = "순위";
            this.dataGridViewTextBoxColumn64.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn64.Name = "dataGridViewTextBoxColumn64";
            this.dataGridViewTextBoxColumn64.ReadOnly = true;
            this.dataGridViewTextBoxColumn64.Width = 50;
            // 
            // dataGridViewTextBoxColumn70
            // 
            this.dataGridViewTextBoxColumn70.DataPropertyName = "pyear";
            this.dataGridViewTextBoxColumn70.HeaderText = "출판일";
            this.dataGridViewTextBoxColumn70.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn70.Name = "dataGridViewTextBoxColumn70";
            this.dataGridViewTextBoxColumn70.ReadOnly = true;
            // 
            // uiLabel10
            // 
            this.uiLabel10.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiLabel10.Location = new System.Drawing.Point(198, 156);
            this.uiLabel10.Name = "uiLabel10";
            this.uiLabel10.Size = new System.Drawing.Size(198, 73);
            this.uiLabel10.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel10.TabIndex = 8;
            this.uiLabel10.Text = "2";
            this.uiLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb3
            // 
            this.tb3.Controls.Add(this.uiPanel3);
            this.tb3.Location = new System.Drawing.Point(0, 40);
            this.tb3.Name = "tb3";
            this.tb3.Size = new System.Drawing.Size(603, 394);
            this.tb3.TabIndex = 2;
            this.tb3.UseVisualStyleBackColor = true;
            // 
            // uiPanel3
            // 
            this.uiPanel3.Controls.Add(this.DGV_rank3);
            this.uiPanel3.Controls.Add(this.uiLabel9);
            this.uiPanel3.FillColor = System.Drawing.Color.Maroon;
            this.uiPanel3.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiPanel3.Location = new System.Drawing.Point(4, 4);
            this.uiPanel3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel3.Name = "uiPanel3";
            this.uiPanel3.Radius = 15;
            this.uiPanel3.RectColor = System.Drawing.Color.Maroon;
            this.uiPanel3.Size = new System.Drawing.Size(595, 385);
            this.uiPanel3.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel3.TabIndex = 0;
            this.uiPanel3.Text = null;
            this.uiPanel3.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DGV_rank3
            // 
            this.DGV_rank3.AllowUserToAddRows = false;
            this.DGV_rank3.AllowUserToDeleteRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.DGV_rank3.AutoGenerateColumns = false;
            this.DGV_rank3.BackgroundColor = System.Drawing.Color.White;
            this.DGV_rank3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.DGV_rank3.ColumnHeadersHeight = 32;
            this.DGV_rank3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_rank3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.DGV_rank3.DataSource = this.bookBindingSource3;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_rank3.DefaultCellStyle = dataGridViewCellStyle13;
            this.DGV_rank3.EnableHeadersVisualStyles = false;
            this.DGV_rank3.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.DGV_rank3.GridColor = System.Drawing.Color.Maroon;
            this.DGV_rank3.Location = new System.Drawing.Point(4, 3);
            this.DGV_rank3.Name = "DGV_rank3";
            this.DGV_rank3.ReadOnly = true;
            this.DGV_rank3.RectColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank3.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.DGV_rank3.RowHeadersVisible = false;
            this.DGV_rank3.RowHeadersWidth = 82;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank3.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.DGV_rank3.RowTemplate.Height = 29;
            this.DGV_rank3.SelectedIndex = -1;
            this.DGV_rank3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_rank3.ShowGridLine = true;
            this.DGV_rank3.Size = new System.Drawing.Size(588, 378);
            this.DGV_rank3.StripeEvenColor = System.Drawing.Color.Snow;
            this.DGV_rank3.StripeOddColor = System.Drawing.Color.Snow;
            this.DGV_rank3.Style = Sunny.UI.UIStyle.Custom;
            this.DGV_rank3.StyleCustomMode = true;
            this.DGV_rank3.TabIndex = 13;
            this.DGV_rank3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_rank_CellClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "bookrank";
            this.dataGridViewTextBoxColumn1.FillWeight = 50F;
            this.dataGridViewTextBoxColumn1.HeaderText = "순위";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "pyear";
            this.dataGridViewTextBoxColumn7.HeaderText = "출판일";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 200;
            // 
            // uiLabel9
            // 
            this.uiLabel9.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiLabel9.Location = new System.Drawing.Point(198, 156);
            this.uiLabel9.Name = "uiLabel9";
            this.uiLabel9.Size = new System.Drawing.Size(198, 73);
            this.uiLabel9.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel9.TabIndex = 7;
            this.uiLabel9.Text = "3";
            this.uiLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb4
            // 
            this.tb4.Controls.Add(this.uiPanel4);
            this.tb4.Location = new System.Drawing.Point(0, 40);
            this.tb4.Name = "tb4";
            this.tb4.Size = new System.Drawing.Size(603, 394);
            this.tb4.TabIndex = 3;
            this.tb4.UseVisualStyleBackColor = true;
            // 
            // uiPanel4
            // 
            this.uiPanel4.Controls.Add(this.DGV_rank4);
            this.uiPanel4.Controls.Add(this.uiLabel8);
            this.uiPanel4.FillColor = System.Drawing.Color.Maroon;
            this.uiPanel4.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiPanel4.Location = new System.Drawing.Point(4, 4);
            this.uiPanel4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel4.Name = "uiPanel4";
            this.uiPanel4.Radius = 15;
            this.uiPanel4.RectColor = System.Drawing.Color.Maroon;
            this.uiPanel4.Size = new System.Drawing.Size(595, 385);
            this.uiPanel4.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel4.TabIndex = 0;
            this.uiPanel4.Text = null;
            this.uiPanel4.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DGV_rank4
            // 
            this.DGV_rank4.AllowUserToAddRows = false;
            this.DGV_rank4.AllowUserToDeleteRows = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank4.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.DGV_rank4.AutoGenerateColumns = false;
            this.DGV_rank4.BackgroundColor = System.Drawing.Color.White;
            this.DGV_rank4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.DGV_rank4.ColumnHeadersHeight = 32;
            this.DGV_rank4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_rank4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.DGV_rank4.DataSource = this.bookBindingSource3;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_rank4.DefaultCellStyle = dataGridViewCellStyle18;
            this.DGV_rank4.EnableHeadersVisualStyles = false;
            this.DGV_rank4.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.DGV_rank4.GridColor = System.Drawing.Color.Maroon;
            this.DGV_rank4.Location = new System.Drawing.Point(4, 3);
            this.DGV_rank4.Name = "DGV_rank4";
            this.DGV_rank4.ReadOnly = true;
            this.DGV_rank4.RectColor = System.Drawing.Color.White;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank4.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.DGV_rank4.RowHeadersVisible = false;
            this.DGV_rank4.RowHeadersWidth = 82;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank4.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.DGV_rank4.RowTemplate.Height = 29;
            this.DGV_rank4.SelectedIndex = -1;
            this.DGV_rank4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_rank4.ShowGridLine = true;
            this.DGV_rank4.Size = new System.Drawing.Size(588, 378);
            this.DGV_rank4.StripeEvenColor = System.Drawing.Color.Snow;
            this.DGV_rank4.StripeOddColor = System.Drawing.Color.Snow;
            this.DGV_rank4.Style = Sunny.UI.UIStyle.Custom;
            this.DGV_rank4.StyleCustomMode = true;
            this.DGV_rank4.TabIndex = 14;
            this.DGV_rank4.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_rank_CellClick);
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "bookrank";
            this.dataGridViewTextBoxColumn8.FillWeight = 50F;
            this.dataGridViewTextBoxColumn8.HeaderText = "순위";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 50;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "pyear";
            this.dataGridViewTextBoxColumn14.HeaderText = "출판일";
            this.dataGridViewTextBoxColumn14.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 200;
            // 
            // uiLabel8
            // 
            this.uiLabel8.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiLabel8.Location = new System.Drawing.Point(198, 156);
            this.uiLabel8.Name = "uiLabel8";
            this.uiLabel8.Size = new System.Drawing.Size(198, 73);
            this.uiLabel8.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel8.TabIndex = 6;
            this.uiLabel8.Text = "4";
            this.uiLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb5
            // 
            this.tb5.Controls.Add(this.uiPanel5);
            this.tb5.Location = new System.Drawing.Point(0, 40);
            this.tb5.Name = "tb5";
            this.tb5.Size = new System.Drawing.Size(603, 394);
            this.tb5.TabIndex = 4;
            this.tb5.UseVisualStyleBackColor = true;
            // 
            // uiPanel5
            // 
            this.uiPanel5.Controls.Add(this.DGV_rank5);
            this.uiPanel5.Controls.Add(this.uiLabel7);
            this.uiPanel5.FillColor = System.Drawing.Color.Maroon;
            this.uiPanel5.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiPanel5.Location = new System.Drawing.Point(4, 5);
            this.uiPanel5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel5.Name = "uiPanel5";
            this.uiPanel5.Radius = 15;
            this.uiPanel5.RectColor = System.Drawing.Color.Maroon;
            this.uiPanel5.Size = new System.Drawing.Size(595, 385);
            this.uiPanel5.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel5.TabIndex = 12;
            this.uiPanel5.Text = null;
            this.uiPanel5.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DGV_rank5
            // 
            this.DGV_rank5.AllowUserToAddRows = false;
            this.DGV_rank5.AllowUserToDeleteRows = false;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank5.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.DGV_rank5.AutoGenerateColumns = false;
            this.DGV_rank5.BackgroundColor = System.Drawing.Color.White;
            this.DGV_rank5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank5.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.DGV_rank5.ColumnHeadersHeight = 32;
            this.DGV_rank5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_rank5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21});
            this.DGV_rank5.DataSource = this.bookBindingSource3;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_rank5.DefaultCellStyle = dataGridViewCellStyle23;
            this.DGV_rank5.EnableHeadersVisualStyles = false;
            this.DGV_rank5.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.DGV_rank5.GridColor = System.Drawing.Color.Maroon;
            this.DGV_rank5.Location = new System.Drawing.Point(3, 4);
            this.DGV_rank5.Name = "DGV_rank5";
            this.DGV_rank5.ReadOnly = true;
            this.DGV_rank5.RectColor = System.Drawing.Color.White;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank5.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.DGV_rank5.RowHeadersVisible = false;
            this.DGV_rank5.RowHeadersWidth = 82;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank5.RowsDefaultCellStyle = dataGridViewCellStyle25;
            this.DGV_rank5.RowTemplate.Height = 29;
            this.DGV_rank5.SelectedIndex = -1;
            this.DGV_rank5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_rank5.ShowGridLine = true;
            this.DGV_rank5.Size = new System.Drawing.Size(588, 378);
            this.DGV_rank5.StripeEvenColor = System.Drawing.Color.Snow;
            this.DGV_rank5.StripeOddColor = System.Drawing.Color.Snow;
            this.DGV_rank5.Style = Sunny.UI.UIStyle.Custom;
            this.DGV_rank5.StyleCustomMode = true;
            this.DGV_rank5.TabIndex = 15;
            this.DGV_rank5.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_rank_CellClick);
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "bookrank";
            this.dataGridViewTextBoxColumn15.FillWeight = 50F;
            this.dataGridViewTextBoxColumn15.HeaderText = "순위";
            this.dataGridViewTextBoxColumn15.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 50;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "pyear";
            this.dataGridViewTextBoxColumn21.HeaderText = "출판일";
            this.dataGridViewTextBoxColumn21.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Width = 200;
            // 
            // uiLabel7
            // 
            this.uiLabel7.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiLabel7.Location = new System.Drawing.Point(198, 156);
            this.uiLabel7.Name = "uiLabel7";
            this.uiLabel7.Size = new System.Drawing.Size(198, 73);
            this.uiLabel7.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel7.TabIndex = 6;
            this.uiLabel7.Text = "5";
            this.uiLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb6
            // 
            this.tb6.Controls.Add(this.uiPanel6);
            this.tb6.Location = new System.Drawing.Point(0, 40);
            this.tb6.Name = "tb6";
            this.tb6.Size = new System.Drawing.Size(603, 394);
            this.tb6.TabIndex = 5;
            this.tb6.UseVisualStyleBackColor = true;
            // 
            // uiPanel6
            // 
            this.uiPanel6.Controls.Add(this.DGV_rank6);
            this.uiPanel6.Controls.Add(this.uiLabel6);
            this.uiPanel6.FillColor = System.Drawing.Color.Maroon;
            this.uiPanel6.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiPanel6.Location = new System.Drawing.Point(4, 4);
            this.uiPanel6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel6.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel6.Name = "uiPanel6";
            this.uiPanel6.Radius = 15;
            this.uiPanel6.RectColor = System.Drawing.Color.Maroon;
            this.uiPanel6.Size = new System.Drawing.Size(595, 385);
            this.uiPanel6.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel6.TabIndex = 0;
            this.uiPanel6.Text = null;
            this.uiPanel6.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DGV_rank6
            // 
            this.DGV_rank6.AllowUserToAddRows = false;
            this.DGV_rank6.AllowUserToDeleteRows = false;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank6.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle26;
            this.DGV_rank6.AutoGenerateColumns = false;
            this.DGV_rank6.BackgroundColor = System.Drawing.Color.White;
            this.DGV_rank6.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank6.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.DGV_rank6.ColumnHeadersHeight = 32;
            this.DGV_rank6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_rank6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28});
            this.DGV_rank6.DataSource = this.bookBindingSource3;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_rank6.DefaultCellStyle = dataGridViewCellStyle28;
            this.DGV_rank6.EnableHeadersVisualStyles = false;
            this.DGV_rank6.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.DGV_rank6.GridColor = System.Drawing.Color.Maroon;
            this.DGV_rank6.Location = new System.Drawing.Point(4, 3);
            this.DGV_rank6.Name = "DGV_rank6";
            this.DGV_rank6.ReadOnly = true;
            this.DGV_rank6.RectColor = System.Drawing.Color.White;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank6.RowHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.DGV_rank6.RowHeadersVisible = false;
            this.DGV_rank6.RowHeadersWidth = 82;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle30.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank6.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.DGV_rank6.RowTemplate.Height = 29;
            this.DGV_rank6.SelectedIndex = -1;
            this.DGV_rank6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_rank6.ShowGridLine = true;
            this.DGV_rank6.Size = new System.Drawing.Size(588, 378);
            this.DGV_rank6.StripeEvenColor = System.Drawing.Color.Snow;
            this.DGV_rank6.StripeOddColor = System.Drawing.Color.Snow;
            this.DGV_rank6.Style = Sunny.UI.UIStyle.Custom;
            this.DGV_rank6.StyleCustomMode = true;
            this.DGV_rank6.TabIndex = 16;
            this.DGV_rank6.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_rank_CellClick);
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "bookrank";
            this.dataGridViewTextBoxColumn22.FillWeight = 50F;
            this.dataGridViewTextBoxColumn22.HeaderText = "순위";
            this.dataGridViewTextBoxColumn22.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.Width = 50;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "pyear";
            this.dataGridViewTextBoxColumn28.HeaderText = "출판일";
            this.dataGridViewTextBoxColumn28.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            this.dataGridViewTextBoxColumn28.Width = 200;
            // 
            // uiLabel6
            // 
            this.uiLabel6.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiLabel6.Location = new System.Drawing.Point(198, 156);
            this.uiLabel6.Name = "uiLabel6";
            this.uiLabel6.Size = new System.Drawing.Size(198, 73);
            this.uiLabel6.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel6.TabIndex = 4;
            this.uiLabel6.Text = "6";
            this.uiLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb7
            // 
            this.tb7.Controls.Add(this.uiPanel7);
            this.tb7.Location = new System.Drawing.Point(0, 40);
            this.tb7.Name = "tb7";
            this.tb7.Size = new System.Drawing.Size(603, 394);
            this.tb7.TabIndex = 6;
            this.tb7.UseVisualStyleBackColor = true;
            // 
            // uiPanel7
            // 
            this.uiPanel7.Controls.Add(this.DGV_rank7);
            this.uiPanel7.Controls.Add(this.uiLabel5);
            this.uiPanel7.FillColor = System.Drawing.Color.Maroon;
            this.uiPanel7.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiPanel7.Location = new System.Drawing.Point(4, 4);
            this.uiPanel7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel7.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel7.Name = "uiPanel7";
            this.uiPanel7.Radius = 15;
            this.uiPanel7.RectColor = System.Drawing.Color.Maroon;
            this.uiPanel7.Size = new System.Drawing.Size(595, 385);
            this.uiPanel7.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel7.TabIndex = 0;
            this.uiPanel7.Text = null;
            this.uiPanel7.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DGV_rank7
            // 
            this.DGV_rank7.AllowUserToAddRows = false;
            this.DGV_rank7.AllowUserToDeleteRows = false;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank7.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle31;
            this.DGV_rank7.AutoGenerateColumns = false;
            this.DGV_rank7.BackgroundColor = System.Drawing.Color.White;
            this.DGV_rank7.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle32.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank7.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle32;
            this.DGV_rank7.ColumnHeadersHeight = 32;
            this.DGV_rank7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_rank7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34,
            this.dataGridViewTextBoxColumn35});
            this.DGV_rank7.DataSource = this.bookBindingSource3;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_rank7.DefaultCellStyle = dataGridViewCellStyle33;
            this.DGV_rank7.EnableHeadersVisualStyles = false;
            this.DGV_rank7.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.DGV_rank7.GridColor = System.Drawing.Color.Maroon;
            this.DGV_rank7.Location = new System.Drawing.Point(3, 4);
            this.DGV_rank7.Name = "DGV_rank7";
            this.DGV_rank7.ReadOnly = true;
            this.DGV_rank7.RectColor = System.Drawing.Color.White;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank7.RowHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.DGV_rank7.RowHeadersVisible = false;
            this.DGV_rank7.RowHeadersWidth = 82;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle35.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank7.RowsDefaultCellStyle = dataGridViewCellStyle35;
            this.DGV_rank7.RowTemplate.Height = 29;
            this.DGV_rank7.SelectedIndex = -1;
            this.DGV_rank7.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_rank7.ShowGridLine = true;
            this.DGV_rank7.Size = new System.Drawing.Size(588, 378);
            this.DGV_rank7.StripeEvenColor = System.Drawing.Color.Snow;
            this.DGV_rank7.StripeOddColor = System.Drawing.Color.Snow;
            this.DGV_rank7.Style = Sunny.UI.UIStyle.Custom;
            this.DGV_rank7.StyleCustomMode = true;
            this.DGV_rank7.TabIndex = 17;
            this.DGV_rank7.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_rank_CellClick);
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "bookrank";
            this.dataGridViewTextBoxColumn29.FillWeight = 50F;
            this.dataGridViewTextBoxColumn29.HeaderText = "순위";
            this.dataGridViewTextBoxColumn29.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.Width = 50;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "pyear";
            this.dataGridViewTextBoxColumn35.HeaderText = "출판일";
            this.dataGridViewTextBoxColumn35.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            this.dataGridViewTextBoxColumn35.Width = 200;
            // 
            // uiLabel5
            // 
            this.uiLabel5.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiLabel5.Location = new System.Drawing.Point(198, 156);
            this.uiLabel5.Name = "uiLabel5";
            this.uiLabel5.Size = new System.Drawing.Size(198, 73);
            this.uiLabel5.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel5.TabIndex = 3;
            this.uiLabel5.Text = "7";
            this.uiLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb8
            // 
            this.tb8.Controls.Add(this.uiPanel8);
            this.tb8.Location = new System.Drawing.Point(0, 40);
            this.tb8.Name = "tb8";
            this.tb8.Size = new System.Drawing.Size(603, 394);
            this.tb8.TabIndex = 7;
            this.tb8.UseVisualStyleBackColor = true;
            // 
            // uiPanel8
            // 
            this.uiPanel8.Controls.Add(this.DGV_rank8);
            this.uiPanel8.Controls.Add(this.uiLabel4);
            this.uiPanel8.FillColor = System.Drawing.Color.Maroon;
            this.uiPanel8.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiPanel8.Location = new System.Drawing.Point(4, 4);
            this.uiPanel8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel8.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel8.Name = "uiPanel8";
            this.uiPanel8.Radius = 15;
            this.uiPanel8.RectColor = System.Drawing.Color.Maroon;
            this.uiPanel8.Size = new System.Drawing.Size(595, 385);
            this.uiPanel8.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel8.TabIndex = 0;
            this.uiPanel8.Text = null;
            this.uiPanel8.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DGV_rank8
            // 
            this.DGV_rank8.AllowUserToAddRows = false;
            this.DGV_rank8.AllowUserToDeleteRows = false;
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank8.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle36;
            this.DGV_rank8.AutoGenerateColumns = false;
            this.DGV_rank8.BackgroundColor = System.Drawing.Color.White;
            this.DGV_rank8.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle37.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank8.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.DGV_rank8.ColumnHeadersHeight = 32;
            this.DGV_rank8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_rank8.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn36,
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn38,
            this.dataGridViewTextBoxColumn39,
            this.dataGridViewTextBoxColumn40,
            this.dataGridViewTextBoxColumn41,
            this.dataGridViewTextBoxColumn42});
            this.DGV_rank8.DataSource = this.bookBindingSource3;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_rank8.DefaultCellStyle = dataGridViewCellStyle38;
            this.DGV_rank8.EnableHeadersVisualStyles = false;
            this.DGV_rank8.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.DGV_rank8.GridColor = System.Drawing.Color.Maroon;
            this.DGV_rank8.Location = new System.Drawing.Point(4, 3);
            this.DGV_rank8.Name = "DGV_rank8";
            this.DGV_rank8.ReadOnly = true;
            this.DGV_rank8.RectColor = System.Drawing.Color.White;
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank8.RowHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.DGV_rank8.RowHeadersVisible = false;
            this.DGV_rank8.RowHeadersWidth = 82;
            dataGridViewCellStyle40.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle40.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank8.RowsDefaultCellStyle = dataGridViewCellStyle40;
            this.DGV_rank8.RowTemplate.Height = 29;
            this.DGV_rank8.SelectedIndex = -1;
            this.DGV_rank8.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_rank8.ShowGridLine = true;
            this.DGV_rank8.Size = new System.Drawing.Size(588, 378);
            this.DGV_rank8.StripeEvenColor = System.Drawing.Color.Snow;
            this.DGV_rank8.StripeOddColor = System.Drawing.Color.Snow;
            this.DGV_rank8.Style = Sunny.UI.UIStyle.Custom;
            this.DGV_rank8.StyleCustomMode = true;
            this.DGV_rank8.TabIndex = 18;
            this.DGV_rank8.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_rank_CellClick);
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.DataPropertyName = "bookrank";
            this.dataGridViewTextBoxColumn36.FillWeight = 50F;
            this.dataGridViewTextBoxColumn36.HeaderText = "순위";
            this.dataGridViewTextBoxColumn36.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.ReadOnly = true;
            this.dataGridViewTextBoxColumn36.Width = 50;
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.DataPropertyName = "pyear";
            this.dataGridViewTextBoxColumn42.HeaderText = "출판일";
            this.dataGridViewTextBoxColumn42.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            this.dataGridViewTextBoxColumn42.ReadOnly = true;
            this.dataGridViewTextBoxColumn42.Width = 200;
            // 
            // uiLabel4
            // 
            this.uiLabel4.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiLabel4.Location = new System.Drawing.Point(198, 156);
            this.uiLabel4.Name = "uiLabel4";
            this.uiLabel4.Size = new System.Drawing.Size(198, 73);
            this.uiLabel4.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel4.TabIndex = 2;
            this.uiLabel4.Text = "8";
            this.uiLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb9
            // 
            this.tb9.Controls.Add(this.uiPanel9);
            this.tb9.Location = new System.Drawing.Point(0, 40);
            this.tb9.Name = "tb9";
            this.tb9.Size = new System.Drawing.Size(603, 394);
            this.tb9.TabIndex = 8;
            this.tb9.UseVisualStyleBackColor = true;
            // 
            // uiPanel9
            // 
            this.uiPanel9.Controls.Add(this.DGV_rank9);
            this.uiPanel9.Controls.Add(this.uiLabel3);
            this.uiPanel9.FillColor = System.Drawing.Color.Maroon;
            this.uiPanel9.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiPanel9.Location = new System.Drawing.Point(4, 4);
            this.uiPanel9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel9.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel9.Name = "uiPanel9";
            this.uiPanel9.Radius = 15;
            this.uiPanel9.RectColor = System.Drawing.Color.Maroon;
            this.uiPanel9.Size = new System.Drawing.Size(595, 385);
            this.uiPanel9.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel9.TabIndex = 0;
            this.uiPanel9.Text = null;
            this.uiPanel9.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DGV_rank9
            // 
            this.DGV_rank9.AllowUserToAddRows = false;
            this.DGV_rank9.AllowUserToDeleteRows = false;
            dataGridViewCellStyle41.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank9.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle41;
            this.DGV_rank9.AutoGenerateColumns = false;
            this.DGV_rank9.BackgroundColor = System.Drawing.Color.White;
            this.DGV_rank9.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle42.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle42.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank9.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.DGV_rank9.ColumnHeadersHeight = 32;
            this.DGV_rank9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_rank9.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn43,
            this.dataGridViewTextBoxColumn44,
            this.dataGridViewTextBoxColumn45,
            this.dataGridViewTextBoxColumn46,
            this.dataGridViewTextBoxColumn47,
            this.dataGridViewTextBoxColumn48,
            this.dataGridViewTextBoxColumn49});
            this.DGV_rank9.DataSource = this.bookBindingSource3;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_rank9.DefaultCellStyle = dataGridViewCellStyle43;
            this.DGV_rank9.EnableHeadersVisualStyles = false;
            this.DGV_rank9.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.DGV_rank9.GridColor = System.Drawing.Color.Maroon;
            this.DGV_rank9.Location = new System.Drawing.Point(4, 3);
            this.DGV_rank9.Name = "DGV_rank9";
            this.DGV_rank9.ReadOnly = true;
            this.DGV_rank9.RectColor = System.Drawing.Color.White;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank9.RowHeadersDefaultCellStyle = dataGridViewCellStyle44;
            this.DGV_rank9.RowHeadersVisible = false;
            this.DGV_rank9.RowHeadersWidth = 82;
            dataGridViewCellStyle45.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle45.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle45.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle45.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank9.RowsDefaultCellStyle = dataGridViewCellStyle45;
            this.DGV_rank9.RowTemplate.Height = 29;
            this.DGV_rank9.SelectedIndex = -1;
            this.DGV_rank9.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_rank9.ShowGridLine = true;
            this.DGV_rank9.Size = new System.Drawing.Size(588, 378);
            this.DGV_rank9.StripeEvenColor = System.Drawing.Color.Snow;
            this.DGV_rank9.StripeOddColor = System.Drawing.Color.Snow;
            this.DGV_rank9.Style = Sunny.UI.UIStyle.Custom;
            this.DGV_rank9.StyleCustomMode = true;
            this.DGV_rank9.TabIndex = 19;
            this.DGV_rank9.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_rank_CellClick);
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.DataPropertyName = "bookrank";
            this.dataGridViewTextBoxColumn43.FillWeight = 50F;
            this.dataGridViewTextBoxColumn43.HeaderText = "순위";
            this.dataGridViewTextBoxColumn43.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            this.dataGridViewTextBoxColumn43.ReadOnly = true;
            this.dataGridViewTextBoxColumn43.Width = 50;
            // 
            // dataGridViewTextBoxColumn49
            // 
            this.dataGridViewTextBoxColumn49.DataPropertyName = "pyear";
            this.dataGridViewTextBoxColumn49.HeaderText = "출판일";
            this.dataGridViewTextBoxColumn49.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            this.dataGridViewTextBoxColumn49.ReadOnly = true;
            this.dataGridViewTextBoxColumn49.Width = 200;
            // 
            // uiLabel3
            // 
            this.uiLabel3.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiLabel3.Location = new System.Drawing.Point(198, 156);
            this.uiLabel3.Name = "uiLabel3";
            this.uiLabel3.Size = new System.Drawing.Size(198, 73);
            this.uiLabel3.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel3.TabIndex = 1;
            this.uiLabel3.Text = "9";
            this.uiLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb10
            // 
            this.tb10.Controls.Add(this.uiPanel10);
            this.tb10.Location = new System.Drawing.Point(0, 40);
            this.tb10.Name = "tb10";
            this.tb10.Size = new System.Drawing.Size(603, 394);
            this.tb10.TabIndex = 9;
            this.tb10.UseVisualStyleBackColor = true;
            // 
            // uiPanel10
            // 
            this.uiPanel10.Controls.Add(this.DGV_rank10);
            this.uiPanel10.Controls.Add(this.uiLabel2);
            this.uiPanel10.FillColor = System.Drawing.Color.Maroon;
            this.uiPanel10.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.uiPanel10.Location = new System.Drawing.Point(4, 4);
            this.uiPanel10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel10.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel10.Name = "uiPanel10";
            this.uiPanel10.Radius = 15;
            this.uiPanel10.RectColor = System.Drawing.Color.Maroon;
            this.uiPanel10.Size = new System.Drawing.Size(595, 385);
            this.uiPanel10.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel10.TabIndex = 0;
            this.uiPanel10.Text = null;
            this.uiPanel10.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DGV_rank10
            // 
            this.DGV_rank10.AllowUserToAddRows = false;
            this.DGV_rank10.AllowUserToDeleteRows = false;
            dataGridViewCellStyle46.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank10.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle46;
            this.DGV_rank10.AutoGenerateColumns = false;
            this.DGV_rank10.BackgroundColor = System.Drawing.Color.White;
            this.DGV_rank10.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle47.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle47.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank10.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle47;
            this.DGV_rank10.ColumnHeadersHeight = 32;
            this.DGV_rank10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_rank10.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn50,
            this.dataGridViewTextBoxColumn51,
            this.dataGridViewTextBoxColumn52,
            this.dataGridViewTextBoxColumn53,
            this.dataGridViewTextBoxColumn54,
            this.dataGridViewTextBoxColumn55,
            this.dataGridViewTextBoxColumn56});
            this.DGV_rank10.DataSource = this.bookBindingSource3;
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_rank10.DefaultCellStyle = dataGridViewCellStyle48;
            this.DGV_rank10.EnableHeadersVisualStyles = false;
            this.DGV_rank10.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.DGV_rank10.GridColor = System.Drawing.Color.Maroon;
            this.DGV_rank10.Location = new System.Drawing.Point(3, 4);
            this.DGV_rank10.Name = "DGV_rank10";
            this.DGV_rank10.ReadOnly = true;
            this.DGV_rank10.RectColor = System.Drawing.Color.White;
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle49.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle49.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle49.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank10.RowHeadersDefaultCellStyle = dataGridViewCellStyle49;
            this.DGV_rank10.RowHeadersVisible = false;
            this.DGV_rank10.RowHeadersWidth = 82;
            dataGridViewCellStyle50.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle50.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle50.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle50.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank10.RowsDefaultCellStyle = dataGridViewCellStyle50;
            this.DGV_rank10.RowTemplate.Height = 29;
            this.DGV_rank10.SelectedIndex = -1;
            this.DGV_rank10.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_rank10.ShowGridLine = true;
            this.DGV_rank10.Size = new System.Drawing.Size(588, 378);
            this.DGV_rank10.StripeEvenColor = System.Drawing.Color.Snow;
            this.DGV_rank10.StripeOddColor = System.Drawing.Color.Snow;
            this.DGV_rank10.Style = Sunny.UI.UIStyle.Custom;
            this.DGV_rank10.StyleCustomMode = true;
            this.DGV_rank10.TabIndex = 20;
            this.DGV_rank10.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_rank_CellClick);
            // 
            // dataGridViewTextBoxColumn50
            // 
            this.dataGridViewTextBoxColumn50.DataPropertyName = "bookrank";
            this.dataGridViewTextBoxColumn50.FillWeight = 50F;
            this.dataGridViewTextBoxColumn50.HeaderText = "순위";
            this.dataGridViewTextBoxColumn50.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            this.dataGridViewTextBoxColumn50.ReadOnly = true;
            this.dataGridViewTextBoxColumn50.Width = 50;
            // 
            // dataGridViewTextBoxColumn56
            // 
            this.dataGridViewTextBoxColumn56.DataPropertyName = "pyear";
            this.dataGridViewTextBoxColumn56.HeaderText = "출판일";
            this.dataGridViewTextBoxColumn56.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn56.Name = "dataGridViewTextBoxColumn56";
            this.dataGridViewTextBoxColumn56.ReadOnly = true;
            this.dataGridViewTextBoxColumn56.Width = 200;
            // 
            // uiLabel2
            // 
            this.uiLabel2.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiLabel2.Location = new System.Drawing.Point(54, 73);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Size = new System.Drawing.Size(198, 73);
            this.uiLabel2.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel2.TabIndex = 0;
            this.uiLabel2.Text = "10";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // DGV_Subject
            // 
            this.DGV_Subject.AllowUserToAddRows = false;
            this.DGV_Subject.AllowUserToDeleteRows = false;
            dataGridViewCellStyle51.BackColor = System.Drawing.Color.MistyRose;
            this.DGV_Subject.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle51;
            this.DGV_Subject.BackgroundColor = System.Drawing.Color.Maroon;
            this.DGV_Subject.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            dataGridViewCellStyle52.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle52.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle52.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            dataGridViewCellStyle52.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle52.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_Subject.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle52;
            this.DGV_Subject.ColumnHeadersHeight = 32;
            this.DGV_Subject.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_Subject.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rankDataGridViewTextBoxColumn,
            this.subjectDataGridViewTextBoxColumn});
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle53.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle53.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle53.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle53.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            dataGridViewCellStyle53.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Subject.DefaultCellStyle = dataGridViewCellStyle53;
            this.DGV_Subject.EnableHeadersVisualStyles = false;
            this.DGV_Subject.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.DGV_Subject.GridColor = System.Drawing.Color.White;
            this.DGV_Subject.Location = new System.Drawing.Point(196, 260);
            this.DGV_Subject.Name = "DGV_Subject";
            this.DGV_Subject.ReadOnly = true;
            this.DGV_Subject.RectColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            dataGridViewCellStyle54.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle54.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            dataGridViewCellStyle54.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_Subject.RowHeadersDefaultCellStyle = dataGridViewCellStyle54;
            this.DGV_Subject.RowHeadersVisible = false;
            this.DGV_Subject.RowHeadersWidth = 82;
            dataGridViewCellStyle55.BackColor = System.Drawing.Color.MistyRose;
            this.DGV_Subject.RowsDefaultCellStyle = dataGridViewCellStyle55;
            this.DGV_Subject.RowTemplate.Height = 29;
            this.DGV_Subject.SelectedIndex = -1;
            this.DGV_Subject.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_Subject.ShowGridLine = true;
            this.DGV_Subject.Size = new System.Drawing.Size(276, 324);
            this.DGV_Subject.StripeEvenColor = System.Drawing.Color.MistyRose;
            this.DGV_Subject.StripeOddColor = System.Drawing.Color.MistyRose;
            this.DGV_Subject.Style = Sunny.UI.UIStyle.Custom;
            this.DGV_Subject.StyleCustomMode = true;
            this.DGV_Subject.TabIndex = 10;
            this.DGV_Subject.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_Subject_CellClick);
            // 
            // rankDataGridViewTextBoxColumn
            // 
            this.rankDataGridViewTextBoxColumn.DataPropertyName = "rank";
            this.rankDataGridViewTextBoxColumn.FillWeight = 60F;
            this.rankDataGridViewTextBoxColumn.HeaderText = " 순위";
            this.rankDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.rankDataGridViewTextBoxColumn.Name = "rankDataGridViewTextBoxColumn";
            this.rankDataGridViewTextBoxColumn.ReadOnly = true;
            this.rankDataGridViewTextBoxColumn.Width = 60;
            // 
            // subjectDataGridViewTextBoxColumn
            // 
            this.subjectDataGridViewTextBoxColumn.DataPropertyName = "subject";
            this.subjectDataGridViewTextBoxColumn.FillWeight = 200F;
            this.subjectDataGridViewTextBoxColumn.HeaderText = "장르";
            this.subjectDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.subjectDataGridViewTextBoxColumn.Name = "subjectDataGridViewTextBoxColumn";
            this.subjectDataGridViewTextBoxColumn.ReadOnly = true;
            this.subjectDataGridViewTextBoxColumn.Width = 212;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(854, 23);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(33, 35);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(975, 23);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // bt_signup
            // 
            this.bt_signup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_signup.FillColor = System.Drawing.Color.Transparent;
            this.bt_signup.FillDisableColor = System.Drawing.Color.Transparent;
            this.bt_signup.FillHoverColor = System.Drawing.Color.Transparent;
            this.bt_signup.FillPressColor = System.Drawing.Color.Transparent;
            this.bt_signup.FillSelectedColor = System.Drawing.Color.Transparent;
            this.bt_signup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_signup.ForeColor = System.Drawing.Color.Black;
            this.bt_signup.ForeHoverColor = System.Drawing.Color.Maroon;
            this.bt_signup.Location = new System.Drawing.Point(995, 23);
            this.bt_signup.MinimumSize = new System.Drawing.Size(1, 1);
            this.bt_signup.Name = "bt_signup";
            this.bt_signup.RectColor = System.Drawing.Color.Transparent;
            this.bt_signup.RectDisableColor = System.Drawing.Color.Transparent;
            this.bt_signup.RectHoverColor = System.Drawing.Color.Transparent;
            this.bt_signup.RectPressColor = System.Drawing.Color.Transparent;
            this.bt_signup.RectSelectedColor = System.Drawing.Color.Transparent;
            this.bt_signup.Size = new System.Drawing.Size(100, 35);
            this.bt_signup.Style = Sunny.UI.UIStyle.Custom;
            this.bt_signup.TabIndex = 5;
            this.bt_signup.Text = "Sign up";
            this.bt_signup.Click += new System.EventHandler(this.bt_signup_Click);
            // 
            // bt_signin
            // 
            this.bt_signin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_signin.FillColor = System.Drawing.Color.Transparent;
            this.bt_signin.FillDisableColor = System.Drawing.Color.Transparent;
            this.bt_signin.FillHoverColor = System.Drawing.Color.Transparent;
            this.bt_signin.FillPressColor = System.Drawing.Color.Transparent;
            this.bt_signin.FillSelectedColor = System.Drawing.Color.Transparent;
            this.bt_signin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_signin.ForeColor = System.Drawing.Color.Black;
            this.bt_signin.ForeHoverColor = System.Drawing.Color.Maroon;
            this.bt_signin.Location = new System.Drawing.Point(869, 23);
            this.bt_signin.MinimumSize = new System.Drawing.Size(1, 1);
            this.bt_signin.Name = "bt_signin";
            this.bt_signin.RectColor = System.Drawing.Color.Transparent;
            this.bt_signin.RectDisableColor = System.Drawing.Color.Transparent;
            this.bt_signin.RectHoverColor = System.Drawing.Color.Transparent;
            this.bt_signin.RectPressColor = System.Drawing.Color.Transparent;
            this.bt_signin.RectSelectedColor = System.Drawing.Color.Transparent;
            this.bt_signin.Size = new System.Drawing.Size(100, 35);
            this.bt_signin.Style = Sunny.UI.UIStyle.Custom;
            this.bt_signin.TabIndex = 4;
            this.bt_signin.Text = "Sign in";
            this.bt_signin.Click += new System.EventHandler(this.bt_signin_Click);
            // 
            // bt_exit
            // 
            this.bt_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_exit.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.bt_exit.Image = ((System.Drawing.Image)(resources.GetObject("bt_exit.Image")));
            this.bt_exit.Location = new System.Drawing.Point(1139, 11);
            this.bt_exit.Name = "bt_exit";
            this.bt_exit.Size = new System.Drawing.Size(60, 60);
            this.bt_exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bt_exit.TabIndex = 3;
            this.bt_exit.TabStop = false;
            this.bt_exit.Text = null;
            this.bt_exit.Click += new System.EventHandler(this.bt_exit_Click);
            // 
            // bt_search
            // 
            this.bt_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_search.FillColor = System.Drawing.Color.Maroon;
            this.bt_search.FillDisableColor = System.Drawing.Color.Maroon;
            this.bt_search.FillHoverColor = System.Drawing.Color.Maroon;
            this.bt_search.FillPressColor = System.Drawing.Color.Maroon;
            this.bt_search.FillSelectedColor = System.Drawing.Color.Maroon;
            this.bt_search.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.bt_search.Location = new System.Drawing.Point(1050, 98);
            this.bt_search.MinimumSize = new System.Drawing.Size(1, 1);
            this.bt_search.Name = "bt_search";
            this.bt_search.Radius = 15;
            this.bt_search.RectColor = System.Drawing.Color.Maroon;
            this.bt_search.Size = new System.Drawing.Size(100, 51);
            this.bt_search.Style = Sunny.UI.UIStyle.Custom;
            this.bt_search.TabIndex = 2;
            this.bt_search.Text = "Search";
            this.bt_search.Click += new System.EventHandler(this.bt_search_Click);
            // 
            // txt_search
            // 
            this.txt_search.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_search.FillColor = System.Drawing.Color.White;
            this.txt_search.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.txt_search.ForeColor = System.Drawing.Color.Silver;
            this.txt_search.Location = new System.Drawing.Point(196, 98);
            this.txt_search.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_search.Maximum = 2147483647D;
            this.txt_search.Minimum = -2147483648D;
            this.txt_search.MinimumSize = new System.Drawing.Size(1, 1);
            this.txt_search.Name = "txt_search";
            this.txt_search.Padding = new System.Windows.Forms.Padding(5);
            this.txt_search.Radius = 20;
            this.txt_search.RectColor = System.Drawing.Color.Silver;
            this.txt_search.Size = new System.Drawing.Size(832, 51);
            this.txt_search.Style = Sunny.UI.UIStyle.Custom;
            this.txt_search.TabIndex = 1;
            this.txt_search.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.txt_search.CursorChanged += new System.EventHandler(this.RemovePlaceholder);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(5);
            this.panel2.Size = new System.Drawing.Size(121, 689);
            this.panel2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Maroon;
            this.panel3.Controls.Add(this.bt_signout);
            this.panel3.Controls.Add(this.bt_icon_signout);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.bt_chart);
            this.panel3.Controls.Add(this.bt_recommend);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Location = new System.Drawing.Point(10, 8);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(100, 672);
            this.panel3.TabIndex = 0;
            // 
            // bt_signout
            // 
            this.bt_signout.AutoSize = true;
            this.bt_signout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_signout.ForeColor = System.Drawing.Color.White;
            this.bt_signout.Location = new System.Drawing.Point(12, 605);
            this.bt_signout.Name = "bt_signout";
            this.bt_signout.Size = new System.Drawing.Size(68, 20);
            this.bt_signout.TabIndex = 16;
            this.bt_signout.Text = "Sign out";
            // 
            // bt_icon_signout
            // 
            this.bt_icon_signout.Image = ((System.Drawing.Image)(resources.GetObject("bt_icon_signout.Image")));
            this.bt_icon_signout.Location = new System.Drawing.Point(19, 542);
            this.bt_icon_signout.Name = "bt_icon_signout";
            this.bt_icon_signout.Size = new System.Drawing.Size(60, 60);
            this.bt_icon_signout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bt_icon_signout.TabIndex = 15;
            this.bt_icon_signout.TabStop = false;
            this.bt_icon_signout.Click += new System.EventHandler(this.bt_icon_signout_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 369);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 40);
            this.label2.TabIndex = 4;
            this.label2.Text = "       장르별 \r\n 보유 책 현황";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(19, 212);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 40);
            this.label1.TabIndex = 3;
            this.label1.Text = " 도서관 \r\n   추천";
            // 
            // bt_chart
            // 
            this.bt_chart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_chart.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.bt_chart.Image = ((System.Drawing.Image)(resources.GetObject("bt_chart.Image")));
            this.bt_chart.Location = new System.Drawing.Point(20, 306);
            this.bt_chart.Name = "bt_chart";
            this.bt_chart.Size = new System.Drawing.Size(60, 60);
            this.bt_chart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bt_chart.TabIndex = 2;
            this.bt_chart.TabStop = false;
            this.bt_chart.Text = null;
            this.bt_chart.Click += new System.EventHandler(this.bt_chart_Click);
            // 
            // bt_recommend
            // 
            this.bt_recommend.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_recommend.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.bt_recommend.Image = ((System.Drawing.Image)(resources.GetObject("bt_recommend.Image")));
            this.bt_recommend.Location = new System.Drawing.Point(19, 149);
            this.bt_recommend.Name = "bt_recommend";
            this.bt_recommend.Size = new System.Drawing.Size(60, 60);
            this.bt_recommend.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bt_recommend.TabIndex = 1;
            this.bt_recommend.TabStop = false;
            this.bt_recommend.Text = null;
            this.bt_recommend.Click += new System.EventHandler(this.bt_recommend_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(5, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(90, 90);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // bookBindingSource3
            // 
            this.bookBindingSource3.DataSource = typeof(Book_re.Book);
            // 
            // dataGridViewTextBoxColumn65
            // 
            this.dataGridViewTextBoxColumn65.DataPropertyName = "category";
            this.dataGridViewTextBoxColumn65.HeaderText = "카테고리";
            this.dataGridViewTextBoxColumn65.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn65.Name = "dataGridViewTextBoxColumn65";
            this.dataGridViewTextBoxColumn65.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn66
            // 
            this.dataGridViewTextBoxColumn66.DataPropertyName = "bid";
            this.dataGridViewTextBoxColumn66.HeaderText = "책 번호";
            this.dataGridViewTextBoxColumn66.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn66.Name = "dataGridViewTextBoxColumn66";
            this.dataGridViewTextBoxColumn66.ReadOnly = true;
            this.dataGridViewTextBoxColumn66.Visible = false;
            // 
            // dataGridViewTextBoxColumn67
            // 
            this.dataGridViewTextBoxColumn67.DataPropertyName = "title";
            this.dataGridViewTextBoxColumn67.FillWeight = 150F;
            this.dataGridViewTextBoxColumn67.HeaderText = "  제목";
            this.dataGridViewTextBoxColumn67.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn67.Name = "dataGridViewTextBoxColumn67";
            this.dataGridViewTextBoxColumn67.ReadOnly = true;
            this.dataGridViewTextBoxColumn67.Width = 150;
            // 
            // dataGridViewTextBoxColumn68
            // 
            this.dataGridViewTextBoxColumn68.DataPropertyName = "writer";
            this.dataGridViewTextBoxColumn68.FillWeight = 80F;
            this.dataGridViewTextBoxColumn68.HeaderText = "저자";
            this.dataGridViewTextBoxColumn68.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn68.Name = "dataGridViewTextBoxColumn68";
            this.dataGridViewTextBoxColumn68.ReadOnly = true;
            this.dataGridViewTextBoxColumn68.Width = 80;
            // 
            // dataGridViewTextBoxColumn69
            // 
            this.dataGridViewTextBoxColumn69.DataPropertyName = "publisher";
            this.dataGridViewTextBoxColumn69.HeaderText = "출판사";
            this.dataGridViewTextBoxColumn69.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn69.Name = "dataGridViewTextBoxColumn69";
            this.dataGridViewTextBoxColumn69.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "category";
            this.dataGridViewTextBoxColumn2.HeaderText = "카테고리";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 200;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "bid";
            this.dataGridViewTextBoxColumn3.HeaderText = "책 번호";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            this.dataGridViewTextBoxColumn3.Width = 200;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "title";
            this.dataGridViewTextBoxColumn4.FillWeight = 150F;
            this.dataGridViewTextBoxColumn4.HeaderText = "  제목";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "writer";
            this.dataGridViewTextBoxColumn5.FillWeight = 80F;
            this.dataGridViewTextBoxColumn5.HeaderText = "저자";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 80;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "publisher";
            this.dataGridViewTextBoxColumn6.HeaderText = "출판사";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 200;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "category";
            this.dataGridViewTextBoxColumn9.HeaderText = "카테고리";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 200;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "bid";
            this.dataGridViewTextBoxColumn10.HeaderText = "책 번호";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Visible = false;
            this.dataGridViewTextBoxColumn10.Width = 200;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "title";
            this.dataGridViewTextBoxColumn11.FillWeight = 150F;
            this.dataGridViewTextBoxColumn11.HeaderText = "  제목";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 150;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "writer";
            this.dataGridViewTextBoxColumn12.FillWeight = 80F;
            this.dataGridViewTextBoxColumn12.HeaderText = "저자";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 80;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "publisher";
            this.dataGridViewTextBoxColumn13.HeaderText = "출판사";
            this.dataGridViewTextBoxColumn13.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 200;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "category";
            this.dataGridViewTextBoxColumn16.HeaderText = "카테고리";
            this.dataGridViewTextBoxColumn16.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 200;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "bid";
            this.dataGridViewTextBoxColumn17.HeaderText = "책 번호";
            this.dataGridViewTextBoxColumn17.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Visible = false;
            this.dataGridViewTextBoxColumn17.Width = 200;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "title";
            this.dataGridViewTextBoxColumn18.FillWeight = 150F;
            this.dataGridViewTextBoxColumn18.HeaderText = "  제목";
            this.dataGridViewTextBoxColumn18.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Width = 150;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "writer";
            this.dataGridViewTextBoxColumn19.FillWeight = 80F;
            this.dataGridViewTextBoxColumn19.HeaderText = "저자";
            this.dataGridViewTextBoxColumn19.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Width = 80;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "publisher";
            this.dataGridViewTextBoxColumn20.HeaderText = "출판사";
            this.dataGridViewTextBoxColumn20.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 200;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "category";
            this.dataGridViewTextBoxColumn23.HeaderText = "카테고리";
            this.dataGridViewTextBoxColumn23.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Width = 200;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "bid";
            this.dataGridViewTextBoxColumn24.HeaderText = "책 번호";
            this.dataGridViewTextBoxColumn24.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.Visible = false;
            this.dataGridViewTextBoxColumn24.Width = 200;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "title";
            this.dataGridViewTextBoxColumn25.FillWeight = 150F;
            this.dataGridViewTextBoxColumn25.HeaderText = "  제목";
            this.dataGridViewTextBoxColumn25.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Width = 150;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "writer";
            this.dataGridViewTextBoxColumn26.FillWeight = 80F;
            this.dataGridViewTextBoxColumn26.HeaderText = "저자";
            this.dataGridViewTextBoxColumn26.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Width = 80;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "publisher";
            this.dataGridViewTextBoxColumn27.HeaderText = "출판사";
            this.dataGridViewTextBoxColumn27.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.Width = 200;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "category";
            this.dataGridViewTextBoxColumn30.HeaderText = "카테고리";
            this.dataGridViewTextBoxColumn30.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.Width = 200;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "bid";
            this.dataGridViewTextBoxColumn31.HeaderText = "책 번호";
            this.dataGridViewTextBoxColumn31.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.Visible = false;
            this.dataGridViewTextBoxColumn31.Width = 200;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "title";
            this.dataGridViewTextBoxColumn32.FillWeight = 150F;
            this.dataGridViewTextBoxColumn32.HeaderText = "  제목";
            this.dataGridViewTextBoxColumn32.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            this.dataGridViewTextBoxColumn32.Width = 150;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.DataPropertyName = "writer";
            this.dataGridViewTextBoxColumn33.FillWeight = 80F;
            this.dataGridViewTextBoxColumn33.HeaderText = "저자";
            this.dataGridViewTextBoxColumn33.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            this.dataGridViewTextBoxColumn33.Width = 80;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.DataPropertyName = "publisher";
            this.dataGridViewTextBoxColumn34.HeaderText = "출판사";
            this.dataGridViewTextBoxColumn34.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.ReadOnly = true;
            this.dataGridViewTextBoxColumn34.Width = 200;
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.DataPropertyName = "category";
            this.dataGridViewTextBoxColumn37.HeaderText = "카테고리";
            this.dataGridViewTextBoxColumn37.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.ReadOnly = true;
            this.dataGridViewTextBoxColumn37.Width = 200;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.DataPropertyName = "bid";
            this.dataGridViewTextBoxColumn38.HeaderText = "책 번호";
            this.dataGridViewTextBoxColumn38.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            this.dataGridViewTextBoxColumn38.ReadOnly = true;
            this.dataGridViewTextBoxColumn38.Visible = false;
            this.dataGridViewTextBoxColumn38.Width = 200;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.DataPropertyName = "title";
            this.dataGridViewTextBoxColumn39.FillWeight = 150F;
            this.dataGridViewTextBoxColumn39.HeaderText = "  제목";
            this.dataGridViewTextBoxColumn39.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            this.dataGridViewTextBoxColumn39.ReadOnly = true;
            this.dataGridViewTextBoxColumn39.Width = 150;
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.DataPropertyName = "writer";
            this.dataGridViewTextBoxColumn40.FillWeight = 80F;
            this.dataGridViewTextBoxColumn40.HeaderText = "저자";
            this.dataGridViewTextBoxColumn40.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.ReadOnly = true;
            this.dataGridViewTextBoxColumn40.Width = 80;
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.DataPropertyName = "publisher";
            this.dataGridViewTextBoxColumn41.HeaderText = "출판사";
            this.dataGridViewTextBoxColumn41.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            this.dataGridViewTextBoxColumn41.ReadOnly = true;
            this.dataGridViewTextBoxColumn41.Width = 200;
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.DataPropertyName = "category";
            this.dataGridViewTextBoxColumn44.HeaderText = "카테고리";
            this.dataGridViewTextBoxColumn44.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            this.dataGridViewTextBoxColumn44.ReadOnly = true;
            this.dataGridViewTextBoxColumn44.Width = 200;
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.DataPropertyName = "bid";
            this.dataGridViewTextBoxColumn45.HeaderText = "책 번호";
            this.dataGridViewTextBoxColumn45.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            this.dataGridViewTextBoxColumn45.ReadOnly = true;
            this.dataGridViewTextBoxColumn45.Visible = false;
            this.dataGridViewTextBoxColumn45.Width = 200;
            // 
            // dataGridViewTextBoxColumn46
            // 
            this.dataGridViewTextBoxColumn46.DataPropertyName = "title";
            this.dataGridViewTextBoxColumn46.FillWeight = 150F;
            this.dataGridViewTextBoxColumn46.HeaderText = "  제목";
            this.dataGridViewTextBoxColumn46.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn46.Name = "dataGridViewTextBoxColumn46";
            this.dataGridViewTextBoxColumn46.ReadOnly = true;
            this.dataGridViewTextBoxColumn46.Width = 150;
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.DataPropertyName = "writer";
            this.dataGridViewTextBoxColumn47.FillWeight = 80F;
            this.dataGridViewTextBoxColumn47.HeaderText = "저자";
            this.dataGridViewTextBoxColumn47.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            this.dataGridViewTextBoxColumn47.ReadOnly = true;
            this.dataGridViewTextBoxColumn47.Width = 80;
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.DataPropertyName = "publisher";
            this.dataGridViewTextBoxColumn48.HeaderText = "출판사";
            this.dataGridViewTextBoxColumn48.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            this.dataGridViewTextBoxColumn48.ReadOnly = true;
            this.dataGridViewTextBoxColumn48.Width = 200;
            // 
            // dataGridViewTextBoxColumn51
            // 
            this.dataGridViewTextBoxColumn51.DataPropertyName = "category";
            this.dataGridViewTextBoxColumn51.HeaderText = "카테고리";
            this.dataGridViewTextBoxColumn51.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn51.Name = "dataGridViewTextBoxColumn51";
            this.dataGridViewTextBoxColumn51.ReadOnly = true;
            this.dataGridViewTextBoxColumn51.Width = 200;
            // 
            // dataGridViewTextBoxColumn52
            // 
            this.dataGridViewTextBoxColumn52.DataPropertyName = "bid";
            this.dataGridViewTextBoxColumn52.HeaderText = "책 번호";
            this.dataGridViewTextBoxColumn52.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn52.Name = "dataGridViewTextBoxColumn52";
            this.dataGridViewTextBoxColumn52.ReadOnly = true;
            this.dataGridViewTextBoxColumn52.Visible = false;
            this.dataGridViewTextBoxColumn52.Width = 200;
            // 
            // dataGridViewTextBoxColumn53
            // 
            this.dataGridViewTextBoxColumn53.DataPropertyName = "title";
            this.dataGridViewTextBoxColumn53.FillWeight = 150F;
            this.dataGridViewTextBoxColumn53.HeaderText = "  제목";
            this.dataGridViewTextBoxColumn53.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn53.Name = "dataGridViewTextBoxColumn53";
            this.dataGridViewTextBoxColumn53.ReadOnly = true;
            this.dataGridViewTextBoxColumn53.Width = 150;
            // 
            // dataGridViewTextBoxColumn54
            // 
            this.dataGridViewTextBoxColumn54.DataPropertyName = "writer";
            this.dataGridViewTextBoxColumn54.FillWeight = 80F;
            this.dataGridViewTextBoxColumn54.HeaderText = "저자";
            this.dataGridViewTextBoxColumn54.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn54.Name = "dataGridViewTextBoxColumn54";
            this.dataGridViewTextBoxColumn54.ReadOnly = true;
            this.dataGridViewTextBoxColumn54.Width = 80;
            // 
            // dataGridViewTextBoxColumn55
            // 
            this.dataGridViewTextBoxColumn55.DataPropertyName = "publisher";
            this.dataGridViewTextBoxColumn55.HeaderText = "출판사";
            this.dataGridViewTextBoxColumn55.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn55.Name = "dataGridViewTextBoxColumn55";
            this.dataGridViewTextBoxColumn55.ReadOnly = true;
            this.dataGridViewTextBoxColumn55.Width = 200;
            // 
            // bookRankBindingSource
            // 
            this.bookRankBindingSource.DataSource = typeof(Book_re.BookRank);
            // 
            // pyear
            // 
            this.pyear.DataPropertyName = "pyear";
            this.pyear.HeaderText = "출판일";
            this.pyear.MinimumWidth = 10;
            this.pyear.Name = "pyear";
            this.pyear.ReadOnly = true;
            // 
            // publisherDataGridViewTextBoxColumn
            // 
            this.publisherDataGridViewTextBoxColumn.DataPropertyName = "publisher";
            this.publisherDataGridViewTextBoxColumn.HeaderText = "출판사";
            this.publisherDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.publisherDataGridViewTextBoxColumn.Name = "publisherDataGridViewTextBoxColumn";
            this.publisherDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // writerDataGridViewTextBoxColumn
            // 
            this.writerDataGridViewTextBoxColumn.DataPropertyName = "writer";
            this.writerDataGridViewTextBoxColumn.FillWeight = 80F;
            this.writerDataGridViewTextBoxColumn.HeaderText = "저자";
            this.writerDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.writerDataGridViewTextBoxColumn.Name = "writerDataGridViewTextBoxColumn";
            this.writerDataGridViewTextBoxColumn.ReadOnly = true;
            this.writerDataGridViewTextBoxColumn.Width = 80;
            // 
            // titleDataGridViewTextBoxColumn
            // 
            this.titleDataGridViewTextBoxColumn.DataPropertyName = "title";
            this.titleDataGridViewTextBoxColumn.FillWeight = 150F;
            this.titleDataGridViewTextBoxColumn.HeaderText = "  제목";
            this.titleDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.titleDataGridViewTextBoxColumn.Name = "titleDataGridViewTextBoxColumn";
            this.titleDataGridViewTextBoxColumn.ReadOnly = true;
            this.titleDataGridViewTextBoxColumn.Width = 150;
            // 
            // bidDataGridViewTextBoxColumn
            // 
            this.bidDataGridViewTextBoxColumn.DataPropertyName = "bid";
            this.bidDataGridViewTextBoxColumn.HeaderText = "책 번호";
            this.bidDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.bidDataGridViewTextBoxColumn.Name = "bidDataGridViewTextBoxColumn";
            this.bidDataGridViewTextBoxColumn.ReadOnly = true;
            this.bidDataGridViewTextBoxColumn.Visible = false;
            this.bidDataGridViewTextBoxColumn.Width = 200;
            // 
            // categoryDataGridViewTextBoxColumn
            // 
            this.categoryDataGridViewTextBoxColumn.DataPropertyName = "category";
            this.categoryDataGridViewTextBoxColumn.HeaderText = "카테고리";
            this.categoryDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.categoryDataGridViewTextBoxColumn.Name = "categoryDataGridViewTextBoxColumn";
            this.categoryDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bookrank
            // 
            this.bookrank.DataPropertyName = "bookrank";
            this.bookrank.FillWeight = 50F;
            this.bookrank.HeaderText = "순위";
            this.bookrank.MinimumWidth = 10;
            this.bookrank.Name = "bookrank";
            this.bookrank.ReadOnly = true;
            this.bookrank.Width = 50;
            // 
            // DGV_rank1
            // 
            this.DGV_rank1.AllowUserToAddRows = false;
            this.DGV_rank1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DGV_rank1.AutoGenerateColumns = false;
            this.DGV_rank1.BackgroundColor = System.Drawing.Color.White;
            this.DGV_rank1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DGV_rank1.ColumnHeadersHeight = 32;
            this.DGV_rank1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGV_rank1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bookrank,
            this.categoryDataGridViewTextBoxColumn,
            this.bidDataGridViewTextBoxColumn,
            this.titleDataGridViewTextBoxColumn,
            this.writerDataGridViewTextBoxColumn,
            this.publisherDataGridViewTextBoxColumn,
            this.pyear});
            this.DGV_rank1.DataSource = this.bookBindingSource3;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_rank1.DefaultCellStyle = dataGridViewCellStyle3;
            this.DGV_rank1.EnableHeadersVisualStyles = false;
            this.DGV_rank1.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.DGV_rank1.GridColor = System.Drawing.Color.Maroon;
            this.DGV_rank1.Location = new System.Drawing.Point(4, 4);
            this.DGV_rank1.Name = "DGV_rank1";
            this.DGV_rank1.ReadOnly = true;
            this.DGV_rank1.RectColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_rank1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DGV_rank1.RowHeadersVisible = false;
            this.DGV_rank1.RowHeadersWidth = 82;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.PeachPuff;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            this.DGV_rank1.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.DGV_rank1.RowTemplate.Height = 29;
            this.DGV_rank1.SelectedIndex = -1;
            this.DGV_rank1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_rank1.ShowGridLine = true;
            this.DGV_rank1.Size = new System.Drawing.Size(588, 378);
            this.DGV_rank1.StripeEvenColor = System.Drawing.Color.Snow;
            this.DGV_rank1.StripeOddColor = System.Drawing.Color.Snow;
            this.DGV_rank1.Style = Sunny.UI.UIStyle.Custom;
            this.DGV_rank1.StyleCustomMode = true;
            this.DGV_rank1.TabIndex = 10;
            this.DGV_rank1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_rank_CellClick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1236, 699);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainForm";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.uiTabControl1.ResumeLayout(false);
            this.tb1.ResumeLayout(false);
            this.uiPanel1.ResumeLayout(false);
            this.tb2.ResumeLayout(false);
            this.uiPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank2)).EndInit();
            this.tb3.ResumeLayout(false);
            this.uiPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank3)).EndInit();
            this.tb4.ResumeLayout(false);
            this.uiPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank4)).EndInit();
            this.tb5.ResumeLayout(false);
            this.uiPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank5)).EndInit();
            this.tb6.ResumeLayout(false);
            this.uiPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank6)).EndInit();
            this.tb7.ResumeLayout(false);
            this.uiPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank7)).EndInit();
            this.tb8.ResumeLayout(false);
            this.uiPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank8)).EndInit();
            this.tb9.ResumeLayout(false);
            this.uiPanel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank9)).EndInit();
            this.tb10.ResumeLayout(false);
            this.uiPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Subject)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bt_exit)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bt_icon_signout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bt_chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bt_recommend)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookRankBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_rank1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Sunny.UI.UIButton bt_search;
        private Sunny.UI.UITextBox txt_search;
        private Sunny.UI.UIImageButton bt_chart;
        private Sunny.UI.UIImageButton bt_recommend;
        private Sunny.UI.UIImageButton bt_exit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Sunny.UI.UIButton bt_signin;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Sunny.UI.UIButton bt_signup;
        private Sunny.UI.UIDataGridView DGV_Subject;
        private Sunny.UI.UILabel uiLabel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn rankDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subjectDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource bookRankBindingSource;
        private Sunny.UI.UITabControl uiTabControl1;
        private System.Windows.Forms.TabPage tb1;
        private Sunny.UI.UIPanel uiPanel1;
        private Sunny.UI.UILabel uiLabel11;
        private System.Windows.Forms.TabPage tb2;
        private Sunny.UI.UIPanel uiPanel2;
        private Sunny.UI.UILabel uiLabel10;
        private System.Windows.Forms.TabPage tb3;
        private Sunny.UI.UIPanel uiPanel3;
        private Sunny.UI.UILabel uiLabel9;
        private System.Windows.Forms.TabPage tb4;
        private Sunny.UI.UIPanel uiPanel4;
        private Sunny.UI.UILabel uiLabel8;
        private System.Windows.Forms.TabPage tb5;
        private Sunny.UI.UIPanel uiPanel5;
        private Sunny.UI.UILabel uiLabel7;
        private System.Windows.Forms.TabPage tb6;
        private Sunny.UI.UIPanel uiPanel6;
        private Sunny.UI.UILabel uiLabel6;
        private System.Windows.Forms.TabPage tb7;
        private Sunny.UI.UIPanel uiPanel7;
        private Sunny.UI.UILabel uiLabel5;
        private System.Windows.Forms.TabPage tb8;
        private Sunny.UI.UIPanel uiPanel8;
        private Sunny.UI.UILabel uiLabel4;
        private System.Windows.Forms.TabPage tb9;
        private Sunny.UI.UIPanel uiPanel9;
        private Sunny.UI.UILabel uiLabel3;
        private System.Windows.Forms.TabPage tb10;
        private Sunny.UI.UIPanel uiPanel10;
        private Sunny.UI.UILabel uiLabel2;
        private Sunny.UI.UIDataGridView DGV_rank2;
        private Sunny.UI.UIDataGridView DGV_rank3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private Sunny.UI.UIDataGridView DGV_rank4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private Sunny.UI.UIDataGridView DGV_rank5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private Sunny.UI.UIDataGridView DGV_rank6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private Sunny.UI.UIDataGridView DGV_rank7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private Sunny.UI.UIDataGridView DGV_rank8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private Sunny.UI.UIDataGridView DGV_rank9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private Sunny.UI.UIDataGridView DGV_rank10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn56;
        private System.Windows.Forms.BindingSource bookBindingSource3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn51;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn52;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn53;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn54;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn55;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn64;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn65;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn66;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn67;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn68;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn69;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn70;
        private System.Windows.Forms.PictureBox pictureBox4;
        private Sunny.UI.UIButton bt_mypage;
        private System.Windows.Forms.PictureBox bt_icon_signout;
        private System.Windows.Forms.Label bt_signout;
        private Sunny.UI.UIDataGridView DGV_rank1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookrank;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn writerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn publisherDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pyear;
    }
}

