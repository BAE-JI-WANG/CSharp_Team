﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Book_re
{
    class BookRank
    {
        public string rank { get; set; }
        public string subject { get; set; }
    }
}
