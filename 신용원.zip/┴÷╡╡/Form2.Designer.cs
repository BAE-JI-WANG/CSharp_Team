﻿
namespace 지도
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_history = new System.Windows.Forms.Button();
            this.button_finance = new System.Windows.Forms.Button();
            this.button_sience = new System.Windows.Forms.Button();
            this.button_iron = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button_religion = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_history
            // 
            this.button_history.Location = new System.Drawing.Point(12, 230);
            this.button_history.Name = "button_history";
            this.button_history.Size = new System.Drawing.Size(103, 47);
            this.button_history.TabIndex = 2;
            this.button_history.Text = "역사";
            this.button_history.UseVisualStyleBackColor = true;
            // 
            // button_finance
            // 
            this.button_finance.Location = new System.Drawing.Point(12, 124);
            this.button_finance.Name = "button_finance";
            this.button_finance.Size = new System.Drawing.Size(103, 47);
            this.button_finance.TabIndex = 3;
            this.button_finance.Text = "경제";
            this.button_finance.UseVisualStyleBackColor = true;
            this.button_finance.Click += new System.EventHandler(this.button_finance_Click);
            // 
            // button_sience
            // 
            this.button_sience.Location = new System.Drawing.Point(12, 177);
            this.button_sience.Name = "button_sience";
            this.button_sience.Size = new System.Drawing.Size(103, 47);
            this.button_sience.TabIndex = 4;
            this.button_sience.Text = "과학";
            this.button_sience.UseVisualStyleBackColor = true;
            this.button_sience.Click += new System.EventHandler(this.button_sience_Click);
            // 
            // button_iron
            // 
            this.button_iron.Location = new System.Drawing.Point(12, 283);
            this.button_iron.Name = "button_iron";
            this.button_iron.Size = new System.Drawing.Size(103, 47);
            this.button_iron.TabIndex = 5;
            this.button_iron.Text = "철학";
            this.button_iron.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(140, 71);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(474, 259);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // button_religion
            // 
            this.button_religion.Location = new System.Drawing.Point(12, 71);
            this.button_religion.Name = "button_religion";
            this.button_religion.Size = new System.Drawing.Size(103, 47);
            this.button_religion.TabIndex = 7;
            this.button_religion.Text = "종교";
            this.button_religion.UseVisualStyleBackColor = true;
            this.button_religion.Click += new System.EventHandler(this.button_religion_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_religion);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button_iron);
            this.Controls.Add(this.button_sience);
            this.Controls.Add(this.button_finance);
            this.Controls.Add(this.button_history);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_history;
        private System.Windows.Forms.Button button_finance;
        private System.Windows.Forms.Button button_sience;
        private System.Windows.Forms.Button button_iron;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button_religion;
    }
}