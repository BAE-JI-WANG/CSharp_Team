﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 지도
{
    class DBHelper
    {
        public static SqlConnection conn = new SqlConnection();
        public static SqlDataAdapter da;
        public static DataSet ds;
        public static DataTable dt;

        public static void ConnectDB()
        {
            string connect = string.Format("Data Source=({0}); " +
                "Initial Catalog = {1};" +
                "Integrated Security = {2};" +
                "Timeout = 3",
                "local", "MYDB1", "SSPI");
            conn = new SqlConnection(connect);
            conn.Open();
        }

        public static void Religion()
        {
            ConnectDB();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn; 
            //테이블에 날릴 쿼리 추가
            cmd.CommandText = "select * from TB_BOOK Where category = 'religion'"; //  종교인 부분만 골라서 조회하면됨 귀찮으니 걍함
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();

            da.Fill(ds, "TB_BOOK"); 

            conn.Close();
        }
        public static void All()
        {
            ConnectDB();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            //테이블에 날릴 쿼리 추가
            cmd.CommandText = "select * from TB_BOOK"; //  종교인 부분만 골라서 조회하면됨 귀찮으니 걍함
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();

            da.Fill(ds, "TB_BOOK");

            conn.Close();
        }


        public static void sience()
        {
            ConnectDB();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            //테이블에 날릴 쿼리 추가
            cmd.CommandText = "select * from TB_BOOK Where category = 'sience'"; //  종교인 부분만 골라서 조회하면됨 귀찮으니 걍함
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();

            da.Fill(ds, "TB_BOOK");

            conn.Close();
        }

        public static void finance()
        {
            ConnectDB();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            //테이블에 날릴 쿼리 추가
            cmd.CommandText = "select * from TB_BOOK Where category = 'finance'"; //  종교인 부분만 골라서 조회하면됨 귀찮으니 걍함
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();

            da.Fill(ds, "TB_BOOK");

            conn.Close();
        }

        internal static void Religion(string name, string location)
        {
            throw new NotImplementedException();
        }
    }
}
