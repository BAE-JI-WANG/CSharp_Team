﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 지도
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            DataLoad0();
        }

        private void DataLoad()
        {
            DataManager.Load();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = DataManager.tb_books;
        }
        private void DataLoad0()
        {
            DataManager.Load0();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = DataManager.tb_books;
        }
        private void DataLoad2()
        {
            DataManager.Load2();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = DataManager.tb_books;
        }
        private void DataLoad3()
        {
            DataManager.Load3();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = DataManager.tb_books;
        }




        private void button_religion_Click(object sender, EventArgs e)
        {
     
            DataLoad();
        }
  private void button_sience_Click(object sender, EventArgs e)
        {
            DataLoad2();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewSelectedCellCollection temp = dataGridView1.SelectedCells;
            //Console.WriteLine($"{temp[0]}");
            string location = dataGridView1[temp[0].ColumnIndex, temp[0].RowIndex].Value.ToString();
            //Console.WriteLine($"{location}");
            //Form1.searchText = location;
            new Form1(location).ShowDialog();
        }

        private void button_finance_Click(object sender, EventArgs e)
        {
            DataLoad3();
        }
    }
}
