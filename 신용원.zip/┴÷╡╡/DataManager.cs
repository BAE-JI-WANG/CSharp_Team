﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 지도
{
    class DataManager
    {
        public static List<TB_BOOK> tb_books = new List<TB_BOOK>();

        public static void Load()
        {
            DBHelper.Religion();
            tb_books.Clear();

            foreach (DataRow item in DBHelper.ds.Tables[0].Rows)
            {
                TB_BOOK temp = new TB_BOOK();
                temp.name = item["name"].ToString();
                temp.location = item["location"].ToString();
                temp.author = item["author"].ToString();

                tb_books.Add(temp);
            }
        }
        public static void Load0()
        {
            DBHelper.All();
            tb_books.Clear();

            foreach (DataRow item in DBHelper.ds.Tables[0].Rows)
            {
                TB_BOOK temp = new TB_BOOK();
                temp.name = item["name"].ToString();
                temp.location = item["location"].ToString();
                temp.author = item["author"].ToString();

                tb_books.Add(temp);
            }
        }



        public static void Load2()
        {
            DBHelper.sience();
            tb_books.Clear();

            foreach (DataRow item in DBHelper.ds.Tables[0].Rows)
            {
                TB_BOOK temp = new TB_BOOK();
                temp.name = item["name"].ToString();
                temp.location = item["location"].ToString();
                temp.author = item["author"].ToString();

                tb_books.Add(temp);
            }
        }

        public static void Load3()
        {
            DBHelper.finance();
            tb_books.Clear();

            foreach (DataRow item in DBHelper.ds.Tables[0].Rows)
            {
                TB_BOOK temp = new TB_BOOK();
                temp.name = item["name"].ToString();
                temp.location = item["location"].ToString();
                temp.author = item["author"].ToString();

                tb_books.Add(temp);
            }
        }






        public static void Save()
        {
            //DB 값을 싹 날린다.
            DBHelper.Religion();

            foreach (TB_BOOK item in tb_books)
            {
                DBHelper.Religion(item.name, item.location);
            }
        }

    }
}
