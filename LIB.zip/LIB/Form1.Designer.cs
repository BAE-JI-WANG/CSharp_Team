﻿
namespace LIB
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button_East = new System.Windows.Forms.Button();
            this.button_West = new System.Windows.Forms.Button();
            this.button_South = new System.Windows.Forms.Button();
            this.button_North = new System.Windows.Forms.Button();
            this.button_Center = new System.Windows.Forms.Button();
            this.button_Dal = new System.Windows.Forms.Button();
            this.button_Dal2 = new System.Windows.Forms.Button();
            this.button_kinggod = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tBLIBBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLIBBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button_East
            // 
            this.button_East.Location = new System.Drawing.Point(12, 12);
            this.button_East.Name = "button_East";
            this.button_East.Size = new System.Drawing.Size(75, 23);
            this.button_East.TabIndex = 0;
            this.button_East.Text = "동구";
            this.button_East.UseVisualStyleBackColor = true;
            this.button_East.Click += new System.EventHandler(this.button_East_Click);
            // 
            // button_West
            // 
            this.button_West.Location = new System.Drawing.Point(12, 41);
            this.button_West.Name = "button_West";
            this.button_West.Size = new System.Drawing.Size(75, 23);
            this.button_West.TabIndex = 1;
            this.button_West.Text = "서구";
            this.button_West.UseVisualStyleBackColor = true;
            this.button_West.Click += new System.EventHandler(this.button_West_Click);
            // 
            // button_South
            // 
            this.button_South.Location = new System.Drawing.Point(12, 70);
            this.button_South.Name = "button_South";
            this.button_South.Size = new System.Drawing.Size(75, 23);
            this.button_South.TabIndex = 2;
            this.button_South.Text = "남구";
            this.button_South.UseVisualStyleBackColor = true;
            this.button_South.Click += new System.EventHandler(this.button_South_Click);
            // 
            // button_North
            // 
            this.button_North.Location = new System.Drawing.Point(12, 99);
            this.button_North.Name = "button_North";
            this.button_North.Size = new System.Drawing.Size(75, 23);
            this.button_North.TabIndex = 3;
            this.button_North.Text = "북구";
            this.button_North.UseVisualStyleBackColor = true;
            this.button_North.Click += new System.EventHandler(this.button_North_Click);
            // 
            // button_Center
            // 
            this.button_Center.Location = new System.Drawing.Point(12, 128);
            this.button_Center.Name = "button_Center";
            this.button_Center.Size = new System.Drawing.Size(75, 23);
            this.button_Center.TabIndex = 4;
            this.button_Center.Text = "중구";
            this.button_Center.UseVisualStyleBackColor = true;
            this.button_Center.Click += new System.EventHandler(this.button_Center_Click);
            // 
            // button_Dal
            // 
            this.button_Dal.Location = new System.Drawing.Point(12, 157);
            this.button_Dal.Name = "button_Dal";
            this.button_Dal.Size = new System.Drawing.Size(75, 23);
            this.button_Dal.TabIndex = 5;
            this.button_Dal.Text = "달서구";
            this.button_Dal.UseVisualStyleBackColor = true;
            this.button_Dal.Click += new System.EventHandler(this.button_Dal_Click);
            // 
            // button_Dal2
            // 
            this.button_Dal2.Location = new System.Drawing.Point(12, 186);
            this.button_Dal2.Name = "button_Dal2";
            this.button_Dal2.Size = new System.Drawing.Size(75, 23);
            this.button_Dal2.TabIndex = 6;
            this.button_Dal2.Text = "달성군";
            this.button_Dal2.UseVisualStyleBackColor = true;
            this.button_Dal2.Click += new System.EventHandler(this.button_Dal2_Click);
            // 
            // button_kinggod
            // 
            this.button_kinggod.Location = new System.Drawing.Point(12, 215);
            this.button_kinggod.Name = "button_kinggod";
            this.button_kinggod.Size = new System.Drawing.Size(75, 23);
            this.button_kinggod.TabIndex = 7;
            this.button_kinggod.Text = "수성구";
            this.button_kinggod.UseVisualStyleBackColor = true;
            this.button_kinggod.Click += new System.EventHandler(this.button_kinggod_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.categoryDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tBLIBBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(108, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(244, 226);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // categoryDataGridViewTextBoxColumn
            // 
            this.categoryDataGridViewTextBoxColumn.DataPropertyName = "category";
            this.categoryDataGridViewTextBoxColumn.HeaderText = "category";
            this.categoryDataGridViewTextBoxColumn.Name = "categoryDataGridViewTextBoxColumn";
            this.categoryDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tBLIBBindingSource
            // 
            this.tBLIBBindingSource.DataSource = typeof(LIB.TB_LIB);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button_kinggod);
            this.Controls.Add(this.button_Dal2);
            this.Controls.Add(this.button_Dal);
            this.Controls.Add(this.button_Center);
            this.Controls.Add(this.button_North);
            this.Controls.Add(this.button_South);
            this.Controls.Add(this.button_West);
            this.Controls.Add(this.button_East);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLIBBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_East;
        private System.Windows.Forms.Button button_West;
        private System.Windows.Forms.Button button_South;
        private System.Windows.Forms.Button button_North;
        private System.Windows.Forms.Button button_Center;
        private System.Windows.Forms.Button button_Dal;
        private System.Windows.Forms.Button button_Dal2;
        private System.Windows.Forms.Button button_kinggod;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource tBLIBBindingSource;
    }
}

