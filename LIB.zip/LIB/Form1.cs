﻿ using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;




namespace LIB
{
    public partial class Form1 : Form
    {
        public object East { get; private set; }

        public Form1()
        {
            InitializeComponent();
            DataLoad();
        }

        private void DataLoad()
        {
            DataManager.Load();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = DataManager.tb_lib;
      
        }
  



        
      

        private void button_East_Click(object sender, EventArgs e)
        {


         
            DBHelper.Read("East");
            dataGridView1.DataSource = null;
            if(DBHelper.ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = DBHelper.ds;
                dataGridView1.DataMember = "TB_L";
            }

         

        }

        private void button_West_Click(object sender, EventArgs e)
        {

            DBHelper.Read("West");

            dataGridView1.DataSource = null;
            if (DBHelper.ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = DBHelper.ds;
                dataGridView1.DataMember = "TB_L";
            }
        }

        private void button_South_Click(object sender, EventArgs e)
        {
            DBHelper.Read("South");
            dataGridView1.DataSource = null;
            if (DBHelper.ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = DBHelper.ds;
                dataGridView1.DataMember = "TB_L";
            }

        }

        private void button_North_Click(object sender, EventArgs e)
        {
            DBHelper.Read("North");
            dataGridView1.DataSource = null;
            if (DBHelper.ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = DBHelper.ds;
                dataGridView1.DataMember = "TB_L";
            }

        }

        private void button_Center_Click(object sender, EventArgs e)
        {
            DBHelper.Read("Center");

            dataGridView1.DataSource = null;
            if (DBHelper.ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = DBHelper.ds;
                dataGridView1.DataMember = "TB_L";
            }
        }

        private void button_Dal_Click(object sender, EventArgs e)
        {
            DBHelper.Read("Dalsu");
            dataGridView1.DataSource = null;
            if (DBHelper.ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = DBHelper.ds;
                dataGridView1.DataMember = "TB_L";
            }

        }

        private void button_Dal2_Click(object sender, EventArgs e)
        {
            DBHelper.Read("Dalsung");

            dataGridView1.DataSource = null;
            if (DBHelper.ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = DBHelper.ds;
                dataGridView1.DataMember = "TB_L";
            }
        }

        private void button_kinggod_Click(object sender, EventArgs e)
        {
            DBHelper.Read("Susung");
            dataGridView1.DataSource = null;
            if (DBHelper.ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = DBHelper.ds;
                dataGridView1.DataMember = "TB_L";
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewSelectedCellCollection temp = dataGridView1.SelectedCells;
            string location = dataGridView1[temp[0].ColumnIndex, temp[0].RowIndex].Value.ToString();
            new Form2(location).ShowDialog();
        }
    }
}
