﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIB
{




    class DBHelper
    {
        public static SqlConnection conn = new SqlConnection();
        public static SqlDataAdapter da;
        public static DataSet ds;
        public static DataTable dt;

        public static void ConnectDB()
        {
            string connect = string.Format("Data Source=({0}); " +
                "Initial Catalog = {1};" +
                "Integrated Security = {2};" +
                "Timeout = 3",
                "local", "MYDB1", "SSPI");
            conn = new SqlConnection(connect);
            conn.Open();
        }

     

        public static void All()
        {
            ConnectDB();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;       
            cmd.CommandText = "select * from TB_L"; 
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();

            da.Fill(ds, "TB_L");

            conn.Close();
        }


        public static void Read(string category)
        {
            Console.WriteLine(category);
            ConnectDB();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = $"select * from TB_L where category ='{category}'";
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();

            da.Fill(ds, "TB_L");
            conn.Close();
        }









    }
}
