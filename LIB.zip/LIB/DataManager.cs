﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIB
{

    class DataManager
    {
        public static List<TB_LIB> tb_lib = new List<TB_LIB>();

        public static void Load()
        {

            DBHelper.All();
            tb_lib.Clear();


            foreach (DataRow item in DBHelper.ds.Tables[0].Rows)
            {
                TB_LIB temp = new TB_LIB();
                temp.name = item["name"].ToString();
                temp.category = item["category"].ToString();

                tb_lib.Add(temp);
            }
        }












    }
}
